import json
import boto3
import os

# NAME = os.environ['Name']
# VALUE = os.environ['Value']

ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    
    #Read SSM Parameter
    response_name=ssm_client.get_parameters(Names=["Name"])
    response_value=ssm_client.get_parameters(Names=["Value"])
    
    name = response_name['Value']
    value = response_value['Value']
    
    #Write to s3 bucket - read-param-dxc
    content=name+","+value
    s3_client.put_object(Bucket='read-param-dxc', Key='src/ssm_output.txt',Body=content)
